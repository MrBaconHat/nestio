# nestio

**Async-first nested storage with dot-path access and atomic writes.**

nestio lets you read and write deeply nested data files using simple dot-path keys — no manual file handling, no race conditions, no boilerplate. Currently supports **JSON** and **TOML**, with more formats on the way.

---

## Installation

```bash
pip install nestio
```

---

## Quickstart

### JSON

```python
import asyncio
from nestio import Json

async def main():
    db = Json("data/config.json")

    await db.set("user.name", "Alice")
    await db.set("user.settings.theme", "dark")
    await db.set("user.scores", [])

    name = await db.get("user.name")            # "Alice"
    theme = await db.get("user.settings.theme") # "dark"

    await db.append("user.scores", 42)
    await db.update("user.settings", {"language": "en"})
    await db.delete("user.settings.theme")

asyncio.run(main())
```

### TOML

```python
import asyncio
from nestio import Toml

async def main():
    cfg = Toml("data/config.toml")

    await cfg.set("server.host", "localhost")
    await cfg.set("server.port", 8080)
    await cfg.set("database.name", "mydb")

    host = await cfg.get("server.host") # "localhost"

    await cfg.update("server", {"port": 9090, "debug": True})
    await cfg.delete("database.name")

asyncio.run(main())
```

---

## API

All methods are `async` and must be awaited. Both `Json` and `Toml` share the same interface.

### `Json(path)` / `Toml(path)`

Creates a storage instance pointing to a file. The file and any parent directories are created automatically on first write.

```python
db  = Json("path/to/file.json")
cfg = Toml("path/to/file.toml")
```

---

### `get(path, default=None)`

Returns the value at the given dot-path, or `default` if it doesn't exist.

```python
value = await db.get("server.host", default="localhost")
```

---

### `set(path, value)`

Sets the value at the given dot-path. Creates intermediate dicts as needed.

```python
await db.set("server.port", 8080)
```

---

### `delete(path)`

Removes the key at the given dot-path. Does nothing if the key doesn't exist.

```python
await db.delete("server.port")
```

---

### `append(path, value)`

Appends a value to a list at the given dot-path. Creates the list if it doesn't exist yet.

```python
await db.append("logs", {"level": "info", "msg": "started"})
```

---

### `update(path, new_data)`

Deep-merges a dict into the value at the given dot-path. Nested keys are merged recursively — existing keys not in `new_data` are preserved.

```python
await db.update("config", {"retries": 3, "timeout": 30})
```

---

## How it works

- **Dot-path access** — keys like `"a.b.c"` resolve through nested dicts automatically.
- **Atomic writes** — every save writes to a temp file first, then uses `os.replace()` to swap it in. Your file is never left in a half-written state.
- **Per-key locking** — concurrent writes to the same path are serialized with `asyncio.Lock`, while independent paths can write in parallel. Locks are cleaned up automatically after a TTL.

---

## Supported formats

| Format | Class  | Status |
|--------|--------|--------|
| JSON   | `Json` | ✅ Available |
| TOML   | `Toml` | ✅ Available |
| YAML   | `Yaml` | 🔜 Coming soon |

---

## Requirements

- Python 3.9+
- [`aiofiles`](https://github.com/Tinche/aiofiles)
- [`tomli`](https://github.com/hukkin/tomli) *(Python < 3.11 only)*
- [`tomli-w`](https://github.com/hukkin/tomli-w)

---

## License

MIT © MrBaconHat
